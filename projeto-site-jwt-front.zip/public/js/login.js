
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('loginForm');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = form.username.value;
    const password = form.password.value;

    const res = await fetch('/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });

    const text = await res.text();
    if (res.ok) {
      const token = text.replace('Login bem-sucedido. Token: ', '').trim();
      localStorage.setItem('token', token);
      window.location.href = '/dashboard';
    } else {
      alert('Usuário ou senha inválidos');
    }
  });
});
    